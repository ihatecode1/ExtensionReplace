//zingvn web structure
var temp = [];
var arrNodeTemp = [];

var listZingNode = document.getElementsByTagName("article");
temp.push(listZingNode);
arrNodeTemp = temp[0];
//end zingvn web structure