// var elements = document.getElementsByTagName('div');

// for (var i = 0; i < elements.length; i++) {
//     var element = elements[i];

//     for (var j = 0; j < element.childNodes.length; j++) {
//         var node = element.childNodes[j];
//         // Nếu node.nodeType là một nút văn bản, thuộc tính nodeType sẽ trở lại 3.
//         if (node.nodeType === 3) {
//             var text = node.nodeValue;
//             var replacedText = text.replace(/[Triều Tiên]/gi, '[occho]');

//             if (replacedText !== text) {
//                 element.replaceChild(document.createTextNode(replacedText), node);
//             }
//         }
//     }
// }
// Pretending we have more than one paragraph to look through
jQuery('body').each(function(){
    traverseChildNodes(this);
});
 
function traverseChildNodes(node) {
 
    var next;
 
    if (node.nodeType === 1) {
 
        // (Element node)
 
        if (node = node.firstChild) {
            do {
                // Recursively call traverseChildNodes
                // on each child node
                next = node.nextSibling;
                traverseChildNodes(node);
            } while(node = next);
        }
 
    } else if (node.nodeType === 3) {
 
        // (Text node)
 
        if (/bRFd{5}/.test(node.data)) {
            // Do something interesting here
            alert('FOUND A MATCH!');
        }
 
    }
 
}

